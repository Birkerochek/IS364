<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    $products = parse_ini_file("products.ini", true);

    $name = $_POST['name'];
    $id = $_POST['id'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $stock = $_POST['stock'];

   


    $count = count($products) + 1;

    
    $saveData = "[product_$count]\n";
    $saveData .= "id = \"$id\"\n";
    $saveData .= "name = \"$name\"\n";
    $saveData .= "description = \"$description\"\n";
    $saveData .= "price = \"$price\"\n";
    $saveData .= "stock = \"$stock\"\n";

    if (file_put_contents("products.ini", $saveData, FILE_APPEND)) {
        echo "Товар успешно добавлен!";
    } else {
        echo "Ошибка при записи в файл.";
    }

    
    header("Location: index.php");
    exit;
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form  method="post">
        <input name="id" type="text" placeholder="id" required>
        <input name="name" type="text" placeholder="Name" required>
        <input name="description" type="text" placeholder="description" required>
        <input name="price" type="text" placeholder="price" required>
        <input name="stock" type="text" placeholder="stock" required>
        <input type="submit" value="Отправить">
    </form>
</body>
</html>