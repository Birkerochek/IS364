<?php

function load_products_from_ini($filename) {
    return parse_ini_file($filename, true);
}


function display_product_card($product) {
    echo "<div style='border: 1px solid black; margin: 10px; width: 340px;'>";
    echo "<h2>{$product['name']}</h2>";
    echo "<p>ID: {$product['id']}</p>";
    echo "<p>Описание: {$product['description']}</p>";
    echo "<p>Цена: {$product['price']} руб.</p>";
    echo "<p>На складе: {$product['stock']} шт.</p>";
    echo "</div>";
}


function display_all_products($products) {
    echo "<div>";
    foreach ($products as $product) {
        display_product_card($product);
    }
    echo "</div>";
}


$products = load_products_from_ini('products.ini');


?>
<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Список товаров</h1>
    <?php display_all_products($products); ?>
    <button onclick="document.location.href = '/addCard.php'">Добавить карточку</button>
</body>
</html>
